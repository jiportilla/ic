module.exports = require('./lib/ws281x-native');

module.exports.indexMapping = require('./lib/index-mapping');